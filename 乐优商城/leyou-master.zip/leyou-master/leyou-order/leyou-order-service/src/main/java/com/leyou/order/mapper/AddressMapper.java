package com.leyou.order.mapper;

import com.leyou.order.pojo.Address;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author: 98050
 * @Time: 2018-10-31 09:41
 * @Feature:
 */
public interface AddressMapper extends Mapper<Address> {
}
