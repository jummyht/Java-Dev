package com.leyou.order.mapper;

import com.leyou.order.pojo.SeckillOrder;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author: 98050
 * @Time: 2018-11-15 10:14
 * @Feature:
 */
public interface SeckillOrderMapper extends Mapper<SeckillOrder> {
}
