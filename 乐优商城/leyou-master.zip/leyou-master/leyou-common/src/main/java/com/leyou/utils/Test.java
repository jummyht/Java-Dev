package com.leyou.utils;

import java.util.Arrays;
import java.util.List;

/**
 * Author: 98050
 * Time: 2018-08-05 15:58
 * Feature:
 */
public class Test {
    public static void main(String[] args) {
        List<Integer> lis = Arrays.asList(1, 2, 3);
        lis.forEach(num -> System.out.println(num));
    }
}
