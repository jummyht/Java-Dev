package com.leyou.seckill.mapper;

import com.leyou.order.pojo.SeckillOrder;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author: 98050
 * @Time: 2018-11-19 00:20
 * @Feature:
 */
public interface SeckillOrderMapper extends Mapper<SeckillOrder> {
}
