package com.leyou.seckill.mapper;

import com.leyou.item.pojo.Stock;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author: 98050
 * @Time: 2018-11-10 17:58
 * @Feature:
 */
public interface StockMapper extends Mapper<Stock> {
}
