//import com.leyou.item.bo.SeckillParameter;
//
//import com.leyou.item.pojo.SeckillGoods;
//import com.leyou.utils.JsonUtils;
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.redis.core.BoundHashOperations;
//import org.springframework.data.redis.core.StringRedisTemplate;
//
//import java.util.Date;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
///**
// * @Author: 98050
// * @Time: 2018-11-13 21:36
// * @Feature:
// */
//public class JsonTest {
//
//}
