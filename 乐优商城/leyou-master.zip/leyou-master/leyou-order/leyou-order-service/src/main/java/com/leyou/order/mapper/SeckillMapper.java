package com.leyou.order.mapper;

import com.leyou.item.pojo.SeckillGoods;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author: 98050
 * @Time: 2018-11-10 16:54
 * @Feature:
 */
public interface SeckillMapper extends Mapper<SeckillGoods> {
}
