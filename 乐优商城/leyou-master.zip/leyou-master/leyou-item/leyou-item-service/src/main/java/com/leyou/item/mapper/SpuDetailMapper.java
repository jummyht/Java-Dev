package com.leyou.item.mapper;

import com.leyou.item.pojo.SpuDetail;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author: 98050
 * Time: 2018-08-17 15:52
 * Feature:
 */
@org.apache.ibatis.annotations.Mapper
public interface SpuDetailMapper extends Mapper<SpuDetail> {
}
