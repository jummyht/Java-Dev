package com.leyou.seckill.mapper;

import com.leyou.item.pojo.Sku;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author: 98050
 * @Time: 2018-11-12 16:21
 * @Feature:
 */
public interface SkuMapper extends Mapper<Sku> {
}
