package com.leyou.order.mapper;

import com.leyou.item.pojo.Sku;
import tk.mybatis.mapper.common.Mapper;

/**
 * @Author: 98050
 * @Time: 2018-11-15 21:12
 * @Feature:
 */
public interface SkuMapper extends Mapper<Sku> {
}
